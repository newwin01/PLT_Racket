package edu.handong.csee.plt.AriOperation;

public class Addition extends NumOP {

    public Addition(){
        op = (a, b) -> a + b;
    }


}
