package edu.handong.csee.plt.AriOperation;

public class Multiplication extends NumOP{

    public Multiplication(){ op = (a, b) -> a * b; }

}
