package edu.handong.csee.plt.AriOperation;

public class Subtraction extends NumOP {

    public Subtraction(){
        op = (a, b) -> a - b;
    }


}
