package edu.handong.csee.plt.DefrdSub;

public class mtSub extends DeferdSubAST{

    @Override
    public String getDeferdSubAST() {
        return "(mtSub)";
    }
}
