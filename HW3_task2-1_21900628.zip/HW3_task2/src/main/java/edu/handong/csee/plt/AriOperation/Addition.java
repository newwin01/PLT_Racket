package edu.handong.csee.plt.AriOperation;

import edu.handong.csee.plt.FAE.Add;

public class Addition extends NumOP {

    public Addition(){
        op = (a, b) -> a + b;
    }


}
